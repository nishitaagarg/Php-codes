<?php

for ($i = 15; $i >= 1; $i -= 2) {
    for ($j = 1; $j <= $i; $j++) {
        echo "*";
    }
    echo "<br>";
}

echo "executed by Meghna";

?>
