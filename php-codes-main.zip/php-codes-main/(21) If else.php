<?php

    $a = 20;
    $b = 15;
    
    if ($a > $b) {
        echo "$a is bigger than $b<br>";
    } else {
        echo "$a is NOT bigger than $b<br>";
    }
    echo "executed by Meghna";

?> 
