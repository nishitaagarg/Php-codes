<?php
    define("GREETING", "hello world!");
    echo GREETING;
    echo "<br>";
    echo GREETING;
    echo "executed by Meghna";

?>
