<?php

    echo 'Current PHP version: ' . phpversion() . "<br>";
    echo "executed by Meghna";

?> 
