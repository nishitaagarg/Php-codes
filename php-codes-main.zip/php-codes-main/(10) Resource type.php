
<?php

    // Open a file for reading
    $handle = fopen("9.txt", "r");
    var_dump($handle);
    echo "<br>";
    echo "executed by Meghna";
?>
