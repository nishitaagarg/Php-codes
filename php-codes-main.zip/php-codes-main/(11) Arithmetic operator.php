
<?php

    $x = 10;
    $y = 4;
    
    echo "$x + $y = ". ($x + $y) . "<br>"; // 0utputs: 14
    echo "$x - $y = ". ($x - $y) . "<br>"; // 0utputs: 6
    echo "$x * $y = ". ($x * $y) . "<br>"; // 0utputs: 40
    echo "$x / $y = ". ($x / $y) . "<br>"; // 0utputs: 2.5
    echo "$x % $y = ". ($x % $y) . "<br>"; // 0utputs: 2
    echo "<br>";
    echo "executed by Meghna";

?>
