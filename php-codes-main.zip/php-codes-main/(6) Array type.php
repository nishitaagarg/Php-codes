<?php

    $colors = array("Red", "Green", "Blue");
    var_dump($colors);
    echo "<br><br>";  // Adding line breaks for better readability
    
    $color_codes = array(
        "Red" => "#ff0000",
        "Green" => "#00ff00",
        "Blue" => "#0000ff");
    var_dump($color_codes);
    echo "<br><br>";  // Adding line breaks for better readability

    echo "executed by Meghna";

?>
