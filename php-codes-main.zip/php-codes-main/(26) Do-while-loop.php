<?php

    $i = 1;
    do {
        echo "The number is " . $i . "<br>";
        $i++;
    } while ($i <= 3);
    
    echo "executed by Meghna";

?> 
