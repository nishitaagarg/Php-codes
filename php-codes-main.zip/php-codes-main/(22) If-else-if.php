<?php
 
    $a = 45;
    $b = 70;
    
    if ($a > $b) {
        echo "$a is bigger than $b<br>";
    } 
    elseif ($a == $b) {
        echo "$a is equal to $b<br>";
    } 
    else {
        echo "$a is smaller than $b<br>";
    }

    echo "executed by Meghna";

?>
