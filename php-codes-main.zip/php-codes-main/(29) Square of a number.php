<?php

$number = 5;
$square = $number * $number;

echo "The square of $number is: " . $square . "<br>";
echo "executed by Meghna";

?> 
