<html>
<head>
    <title>Writing PHP Function</title>
</head>
<body>
    <?php
    /* Defining a PHP Function */
    function writeMessage() {
        echo "You are really a nice person, Have a nice time!";
    }
    /* Calling a PHP Function */
    writeMessage();
    echo "executed by Meghna";
    ?>
</body>
</html>
