<?php

    $favcolor = "red";
    
    switch ($favcolor) {
        case "red":
            echo "Your favorite color is red!<br>";
            break;
        case "blue":
            echo "Your favorite color is blue!<br>";
            break;
        case "green":
            echo "Your favorite color is green!<br>";
            break;
        default:
            echo "Your favorite color is neither red, blue, nor green!<br>";
    }

    echo "executed by Meghna";
    
?> 
