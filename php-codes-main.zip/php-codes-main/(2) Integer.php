<?php

    $a = 123; // decimal number
    var_dump($a);
     
    $b = -123; // a negative number
    var_dump($b);
     
    $c = 0x1A; // hexadecimal number
    var_dump($c);
     
    $d = 0123; // octal number
    var_dump($d);
    echo "<br>";
    echo "executed by Meghna";


?>
