
<?php

    $str="hello string";  
    $x=200;  
    $y=44.6;  
    echo "string is: $str <br>";  
    echo "integer is: $x <br>";  
    echo "float is: $y <br>";  
    echo "executed by Meghna";
?>
