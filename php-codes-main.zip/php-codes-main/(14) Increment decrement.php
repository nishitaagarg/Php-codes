<?php

    $x = 10;
    echo "++$x is =" . (++$x) . "<br>"; 
    echo "Now x is =" . $x . "<br>";   
    
    $x = 10;
    echo "$x++ is =" . ($x++) . "<br>"; 
    echo "Now x is =" . $x . "<br>";  
    
    $x = 10;
    echo "--$x is =" . (--$x) . "<br>"; 
    echo "Now x is =" . $x . "<br>";   
    
    $x = 10;
    echo "$x-- is =" . ($x--) . "<br>";
    echo "Now x is =" . $x;   
    echo "<br>";
    echo "executed by Meghna";
