<?php

    $a = 10;
    $b = 20;
    if($a < $b)
    {
        echo "Out of $a and $b, $a is smaller..<br>" ;
    }
    echo "executed by Meghna";

?>
