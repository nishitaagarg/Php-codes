
<?php

    $a = NULL;
    var_dump($a);
     
    $b = "Hello World!";
    $b = NULL;
    var_dump($b);
    echo "<br>";
    echo "executed by Meghna";

?>
