
<?php

    // Assign the value TRUE to a variable
    $show_error = true;
    var_dump($show_error);
    echo "<br>";
    echo "executed by Meghna";
    

?>
