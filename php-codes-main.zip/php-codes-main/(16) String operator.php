<?php

    $x = "Hello";
    $y = " World!";
    echo $x . $y; 
    echo "<br>";
    $x .= $y;
    echo $x; 
    echo "<br>";
    echo "executed by Meghna";

?>
