<?php

    $a = "Hello world!<br>";
    echo $a;
     
    $b = "Hello world!<br>";
    echo $b;
     
    $c = "Stay here, I'll be back.";
    echo $c;
    echo "<br>";
    echo "executed by Meghna"

?>
